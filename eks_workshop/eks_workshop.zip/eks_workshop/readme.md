## EKS Workshop Scripts

These scripts configure the cloud9 instance in the eks workshop as well  as clean it up.

## Latest Versions:
eks_launch.sh: 0.3
cleanup.sh: 0.3
